---
name: amiga-protracker-mod-generator
description: Generate, repair, inspect, render, and validate authentic Amiga ProTracker 4-channel M.K. modules with embedded signed 8-bit samples, channel-efficient combined percussion samples, correct 0xy tick arpeggios, PAL/NTSC pitch analysis, preview audio, and validation reports.
argument-hint: "title; genre; BPM; mood; duration; key or scale; rhythmic feel; optional production language"
effort: high
---

# Amiga ProTracker MOD Generator

Produce the actual playable `.mod` artifact. Do not stop at composition advice, pseudocode, pattern text, or a binary-format explanation.

## Authoritative methodology

Before generating, modifying, repairing, rendering, or validating a module, read the complete reference:

- [references/master-prompt.md](references/master-prompt.md)

It is the authoritative technical and musical specification. Apply all constraints, especially the rules for Paula channel economy, combined samples, `0xy` arpeggios, pitch validation, binary validation, and honest reporting.

## Parse the musical brief

Interpret `$ARGUMENTS` as the requested track specification. Extract when present:

- title
- genre
- BPM
- mood
- approximate duration
- key or scale
- rhythmic feel
- historical or production language
- requested instrumentation or structural requirements

When non-critical information is absent, use conservative documented defaults rather than producing no artifact:

- title: an original descriptive working title
- BPM: 125
- speed: 6 unless another valid timing design is required
- duration: approximately 2 minutes
- key: A minor
- rhythmic feel: straight

Do not copy a protected melody, bass line, hook, lyric, recognizable arpeggio, signature arrangement, or complete song structure.

## Mandatory production workflow

1. Read the master reference completely.
2. Convert the brief into an arrangement plan containing sections, order list, channel roles, sample inventory, note ranges, harmonic plan, rhythmic plan, effects, and transitions.
3. Create a four-channel resource plan before writing patterns. Treat every Paula channel as monophonic and scarce.
4. Identify simultaneous percussion hits that can be represented by intentional combined samples without reducing clarity. Examples include `KICK+SNARE`, `KICK+CLAP`, `KICK+OPEN HAT`, `SNARE+CLAP`, and `HAT+SHAKER`.
5. Generate all samples as embedded signed 8-bit mono PCM with even byte lengths, valid loop fields, controlled DC offset, preserved headroom, and no accidental clipping.
6. For every combined sample, align transients, balance components before quantization, check phase interaction, preserve the kick body where applicable, and design the tail around later note interruption on the same channel.
7. For every pitched sample, verify the true fundamental and calculate its behavior from source waveform, source synthesis rate, tracker period, PAL playback rate, NTSC playback rate, finetune, and every note actually used.
8. Compose meaningful 64-row patterns with recognizable sections, controlled repetition, fills, transitions, density changes, melodic development, and a coherent ending or intentional loop.
9. Implement ProTracker `0xy` arpeggios as real tick effects. At normal speed, reproduce the repeating `base, +x, +y` tick sequence. Do not substitute manually sequenced notes and call them `0xy`.
10. Use a valid sample number when an arpeggiated phrase first selects its instrument. Do not rely on sample memory before a sample has been established on that channel.
11. Use simple, correctly tuned monophonic samples for arpeggios unless a more complex sample has been deliberately tested. Avoid blind use of `0xy` on chord samples, noise, or inharmonic material.
12. Build a genuine ProTracker 2.x-style module with 31 sample headers, 64-row patterns, 4 channels, correct four-byte event encoding, a valid 128-byte order table, `M.K.` at offset 1080, and embedded sample data.
13. Derive stored pattern count from the highest pattern number in the complete 128-byte order table, not only the active song positions.
14. Validate exact file size, offsets, sample lengths, loops, finetunes, volumes, periods, effects, pattern references, sample references, note ranges, and order data.
15. Validate every `0xy` command: sample state, semitone offsets, harmonic meaning, resulting note range, safe playback rate, and tick behavior.
16. Report every combined sample and explain which simultaneous event or channel use it replaced. Do not claim a channel saving unless the pattern data demonstrates it.
17. Render a control WAV when local tools permit. The renderer must implement every effect used in the module or clearly disclose unsupported behavior.
18. Inspect measured WAV duration, RMS, peak, clipping, stereo balance, and silence. When possible, perform a real listening check and distinguish it from numerical analysis.
19. Reject and regenerate output that is silent, weak, wrongly tuned, clipped, repetitive, badly balanced, structurally invalid, or musically unconvincing.
20. Package all created deliverables in a ZIP.

## Technical implementation rules

- Prefer deterministic, reusable local source code for sample synthesis, pattern generation, MOD writing, rendering, and validation.
- Keep generation, rendering, and validation as separate components when practical.
- Preserve classic Amiga panning: channels 1 and 4 left; channels 2 and 3 right.
- Use tuning-zero periods unless finetune is intentionally implemented and validated.
- Arpeggio transposition must follow semitone relationships and valid ProTracker note periods, not arbitrary period subtraction.
- Keep all arpeggiated notes within `C-1` to `B-3` and within safe practical playback rates.
- Do not correct inaudibility only by raising volume. Diagnose pitch, octave, waveform, duration, loop, envelope, spectrum, and channel competition.
- Do not combine full-level samples by blind addition. Mix with headroom before signed 8-bit quantization.
- Do not maximize all channels or samples.
- Never rename another format to `.mod`.
- Never deliver a placeholder, empty demonstration, or fake validation result.
- Never claim physical Amiga, real tracker, or listening validation unless it actually occurred.

## Required deliverables

Create:

- `<title>.mod`
- `<title>_preview.wav` when technically possible
- `README.txt`
- `VALIDATION_REPORT.txt`
- reproducible generator and validator source files when useful
- `<title>_deliverables.zip`

## README requirements

Include:

- title, genre, BPM, speed, key, mood, duration
- number of patterns and active order list
- channel assignments
- sample list and sample specifications
- combined samples and their intended simultaneous components
- effects used, including `0xy` commands
- note ranges
- PAL and NTSC references
- compatibility notes
- originality statement
- validation levels performed and limitations

Credit exactly:

- Methodology and technical direction: Fabrizio Radica
- Project: RadicaDesign
- Website: www.radicadesign.com

## Validation report requirements

Include measured or directly inspected values for:

- actual and expected file size
- SHA-256
- `M.K.` signature
- song length and compatibility/restart byte
- complete order-table scan and stored pattern count
- sample offsets, byte lengths, finetunes, volumes, and loops
- pattern structure, periods, note ranges, sample references, and effects
- all `0xy` commands, their sample state, tick sequence, chord intervals, and resulting note ranges
- all combined samples, component balance checks, trigger usage, and demonstrated channel capacity released
- non-empty event density
- pitched-sample fundamentals and PAL/NTSC playback-rate ranges
- preview WAV duration, RMS, peak, clipping, silence, and renderer limitations

Label validation levels separately:

- binary validation
- spectral validation
- approximate software render
- real tracker playback
- physical Amiga playback

Only claim levels actually performed.

## Final response

Provide direct links only to files that were actually created. Include the `.mod`, ZIP, README, validation report, preview WAV, and source files when present. Briefly disclose any validation or listening step that could not be performed.
