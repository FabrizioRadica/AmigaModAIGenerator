# Amiga ProTracker MOD Generator Skill

Claude Code skill for generating, repairing, rendering, inspecting, and validating authentic four-channel Amiga ProTracker `M.K.` modules.

This revision explicitly supports:

- real ProTracker `0xy` arpeggios reproduced tick by tick
- major `047` and minor `037` triad logic
- valid sample-state handling at the beginning of arpeggiated phrases
- channel optimization through deliberately premixed percussion samples
- validation of channel capacity released by combined samples
- PAL/NTSC pitch and playback-rate analysis
- exact binary and sample-offset validation
- optional control WAV generation and measured audio checks

## Install globally

Copy the complete folder to:

```text
~/.claude/skills/amiga-protracker-mod-generator/
```

On Windows:

```text
%USERPROFILE%\.claude\skills\amiga-protracker-mod-generator\
```

Expected structure:

```text
amiga-protracker-mod-generator/
├── SKILL.md
├── README.md
├── CHANGELOG.md
├── examples/
│   └── usage.md
└── references/
    └── master-prompt.md
```

## Invoke

```text
/amiga-protracker-mod-generator "Machine Riot; 128 BPM; E minor; aggressive 1980s synth-pop dance; approximately 2 minutes; four-on-the-floor; use channel-efficient drums and chip arpeggios"
```

Claude may also activate the skill automatically for requests that clearly involve authentic ProTracker `.mod` generation, repair, rendering, or validation.

## Design

`SKILL.md` contains the operational workflow and non-negotiable checks. The complete methodology remains in `references/master-prompt.md` and is loaded when the skill is used, keeping the permanent skill definition more compact than the full technical reference.
