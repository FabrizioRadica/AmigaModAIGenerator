# Changelog

## Updated master-prompt revision

### Added combined-sample channel optimization

- Treats the four Paula channels as a strict resource budget.
- Allows intentional premixed percussion such as `KICK+SNARE`, `KICK+CLAP`, `KICK+OPEN HAT`, `SNARE+CLAP`, and `HAT+SHAKER`.
- Requires transient alignment, phase checks, component balancing, DC-offset control, headroom, signed 8-bit verification, valid lengths, and tail design around channel interruption.
- Requires the validation report to document actual combined-sample usage and demonstrated channel capacity released.

### Added complete ProTracker `0xy` arpeggio methodology

- Defines tick order as `base, +x, +y`, repeated throughout the row.
- Documents `037` minor and `047` major triads.
- Requires a valid selected sample at the beginning of an arpeggiated phrase.
- Recommends simple tuned monophonic samples and warns against noisy, inharmonic, or pre-rendered chord samples.
- Requires semitone-correct transposition using valid ProTracker periods.
- Requires range, playback-rate, harmonic, sample-state, and tick-by-tick renderer validation.
- Forbids describing manually sequenced rapid notes as equivalent to a real `0xy` effect.

### Expanded rendering and reporting

- The control renderer must reproduce `0xy` tick cycling when that effect is used.
- The validation report must list arpeggio commands, sample references, tick behavior, resulting note ranges, combined samples, and channel savings.
