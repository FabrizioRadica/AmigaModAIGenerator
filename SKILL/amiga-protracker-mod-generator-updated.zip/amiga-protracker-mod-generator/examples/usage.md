# Usage examples

## Dance module with channel-efficient drums

```text
/amiga-protracker-mod-generator "Title: Machine Riot; genre: 1980s synth-pop dance with rave influence; BPM: 128; duration: 2 minutes; key: E minor; feel: straight four-on-the-floor; use KICK on beats 1 and 3 and KICK+SNARE on beats 2 and 4 when this releases a Paula channel"
```

## Chip-style arpeggio module

```text
/amiga-protracker-mod-generator "Title: Neon Circuit; genre: melodic chiptune; BPM: 140; key: A minor; duration: 1:45; use authentic ProTracker 037 minor and 047 major arpeggios on simple tuned pulse samples; validate every tick and resulting note range"
```

## Inspect or repair an existing module

```text
Use the amiga-protracker-mod-generator skill to inspect this MOD, repair invalid offsets or effects, verify every 0xy arpeggio and combined percussion sample, render a control WAV where possible, and return the repaired module with a validation report.
```
