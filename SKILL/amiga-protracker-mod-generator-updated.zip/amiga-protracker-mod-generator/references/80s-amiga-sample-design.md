# 1980s-Inspired Amiga Sample Design Reference

## Purpose and scope

Use this reference to design original 1980s-inspired instrument samples for genuine four-channel Amiga ProTracker modules.

This document describes broad synthesis, production and arrangement vocabulary. It is not an auditory transcription of any linked video or commercial sample pack, and it must not be used to extract, copy or redistribute protected samples.

Recreate every sound from original synthesis, procedural generation, licensed source material or user-owned recordings.

## Contents

- Core ProTracker requirements
- General 1980s production language
- Sample families
  - analogue pulse bass and sequencer bass
  - analogue and digital leads
  - synth brass, pads and strings
  - glass plucks and arpeggio waveforms
  - kick, snare, clap and hi-hats
  - combined percussion
  - sweeps, impacts and science-fiction effects
- Simulated 1980s echo
- Loop design
- Conversion and quantization workflow
- Suggested compact sample inventory
- Four-channel planning
- Mandatory validation report
- Originality requirements

## Core ProTracker requirements

Every generated sample must be:

- signed 8-bit PCM
- mono
- embedded in the `.mod`
- an even number of bytes
- free from avoidable DC offset
- quantized with controlled headroom
- correctly represented by its sample-header length
- assigned a valid volume from `0` to `64`
- assigned finetune zero unless another value is intentionally implemented and validated
- given a valid repeat start and repeat length

For pitched material, verify the actual fundamental rather than trusting a filename or intended note label.

Use the Amiga playback formulas:

```text
PAL playback rate  = 7093789.2 / (period × 2)
NTSC playback rate = 7159090.5 / (period × 2)
```

At tuning-zero `C-3`, period `214`:

```text
PAL  ≈ 16574.27 Hz
NTSC ≈ 16726.85 Hz
```

Keep all used notes within `C-1` to `B-3` and normally keep effective playback below approximately 28 kHz.

## General 1980s production language

Typical 1980s-inspired electronic timbres combine:

- stable analogue-style oscillators
- pulse and sawtooth harmonic structures
- bright but controlled digital transients
- short plucks followed by synthetic tails
- slowly evolving pads and strings
- gated or abruptly shortened ambience
- deep electronic kicks
- bright snares with tonal bodies
- layered claps
- precise sequenced bass
- repeating arpeggios
- selective simulated echo
- dramatic noise sweeps and impacts

Do not maximize every sample. Contrast between dark, bright, short, sustained, dry and echoed elements is part of the style.

## Sample families

### 1. Analogue pulse bass

#### Character

- solid low-mid fundamental
- controlled square or pulse-wave edge
- short, decisive attack
- compact decay
- enough second and third harmonic content to remain audible on small speakers

#### Synthesis recipe

1. Generate a square or 25–40% pulse waveform.
2. Add a quieter sine fundamental when more body is required.
3. Add a small second harmonic for definition.
4. Apply a fast attack between approximately 1 and 5 ms.
5. Use a decay between approximately 180 and 450 ms.
6. Apply gentle low-pass shaping rather than removing all upper harmonics.
7. Remove DC offset before quantization.

#### Tracker use

- normal range: `C-2` to `E-3`
- use short notes or `ECx` when the groove requires separation
- avoid masking the kick
- for Eurodance or synthwave, offbeat placement can create strong forward motion

#### Validation

- fundamental must remain audible
- strongest spectral peak must not be an unintended upper harmonic
- bass must survive signed 8-bit conversion
- low notes must not become subsonic or weak

### 2. Sequencer bass

#### Character

- faster and more articulated than the main bass
- suitable for eighth- or sixteenth-note patterns
- narrow pulse, filtered saw or hybrid waveform
- consistent transient

#### Design notes

Keep the sample short enough that repeated tracker notes remain clear. Use alternating roots, fifths, octaves and passing notes with controlled repetition.

Do not make every step equally loud. Subtle `Cxx` variation can create accent movement.

### 3. Monophonic analogue lead

#### Character

- stable saw or pulse foundation
- expressive upper harmonics
- immediate but not clicky attack
- controlled decay or verified sustain loop

#### Synthesis recipe

1. Combine a saw-like harmonic series with a lower-level square component.
2. Slightly soften the highest harmonics to reduce aliasing.
3. Add a short attack and a longer decay than the bass.
4. For sustained use, create a phase-compatible loop inside the stable body.
5. Use `4xy` vibrato only after confirming the sample remains correctly tuned.

#### Tracker use

- normal range: `A-2` to `G#3`
- leave headroom above arpeggios and hats
- use phrase-ending echo selectively
- avoid continuous high-register notes near the practical playback ceiling

### 4. Bright digital lead

#### Character

- glassier and more precise than an analogue lead
- clear fundamental with selected inharmonic or bell-like partials
- short metallic transient
- restrained tail

#### Synthesis recipe

Use a sine-based fundamental plus low-level partials at musically useful ratios. Avoid excessive inharmonic content if the sample will be transposed widely.

Do not apply `0xy` blindly. Rapid period changes can make a complex digital sample harsh or noisy.

### 5. Synth brass stab

#### Character

- bright, forceful attack
- stacked saw-like harmonics
- rapid filter-style opening
- medium-short decay
- dramatic chord or rhythmic accent

#### Synthesis recipe

1. Build a harmonically rich saw-like waveform.
2. Apply a fast amplitude attack.
3. Simulate filter opening by increasing high-frequency energy during the first part of the sample.
4. Shorten the tail to avoid blocking later notes.
5. Keep enough body around the fundamental to survive 8-bit conversion.

#### Tracker use

- use as syncopated punctuation
- consider a pre-rendered chord stab only when its harmony is fixed
- do not combine a chord sample with `0xy` unless deliberately tested

### 6. Warm poly-style pad

#### Character

- slow attack
- evolving body
- controlled high-frequency movement
- wide-feeling source reduced carefully to mono
- sustained, atmospheric role

#### Amiga adaptation

Because each Paula channel is monophonic, a pad can consume substantial channel capacity.

Choose among:

- one long one-shot pad note
- a genuinely looped monophonic pad
- a pre-rendered chord sample for fixed harmony
- a sparse arpeggio suggesting harmony on one channel

Do not use a loop unless the repeat region is valid, phase-compatible and correctly tuned.

### 7. Synth strings

#### Character

- smoother than brass
- layered saw-like harmonic body
- slower attack
- sustained midrange presence

#### Synthesis recipe

Use two slightly different harmonic profiles mixed in mono, not uncontrolled stereo detuning. Apply a gentle attack and a verified loop in the stable body when sustain is required.

Watch for loop beating, clicks and unintended pitch shifts.

### 8. Glass bell or digital pluck

#### Character

- immediate bright transient
- clean tonal body
- fast high-frequency decay
- longer, quieter fundamental tail

#### Synthesis recipe

1. Use a sine fundamental.
2. Add a small number of controlled upper partials.
3. Give each partial a different decay time.
4. Keep the brightest partials brief.
5. End naturally as a one-shot unless a sustain is musically required.

#### Tracker use

- useful for melodies, motifs and sparse accents
- suitable for simulated echo
- avoid dense high-register repetition

### 9. Arpeggio waveform

#### Character

- simple
- stable
- monophonic
- correctly tuned
- resistant to rapid `0xy` transposition

Preferred sources:

- sine
- square
- pulse
- restrained saw

#### Single-row arpeggio

```text
A-2 06 037
```

At speed 6:

```text
A → C → E → A → C → E
```

#### Sustained arpeggio string

Use only a genuinely looped sample:

```text
A-2 06 037
--- 06 037
--- 06 037
C-2 06 047
--- 06 047
--- 06 047
```

Continuation rows preserve the active base note and sample position. Validate loop boundaries, pitch, channel state and every resulting transposed note.

### 10. Deep electronic kick

#### Character

- rapid downward pitch sweep
- short high-frequency click
- controlled low-frequency body
- decay short enough for the next beat

#### Synthesis recipe

1. Start a sine oscillator above the final fundamental.
2. Sweep rapidly downward during the attack.
3. Add a brief click or noise transient.
4. Apply an exponential amplitude decay.
5. Remove unnecessary subsonic tail.
6. Preserve headroom before 8-bit conversion.

Do not make the kick so long that it masks the bass.

### 11. Gated electronic snare

#### Character

- bright noise burst
- short tonal body
- abrupt or gated tail
- strong backbeat presence

#### Synthesis recipe

Mix filtered noise with a quieter tonal component around the low-mid range. Apply a sharp envelope and controlled cutoff.

The classic gated character should be suggested by the envelope, not by embedding a long, muddy ambience.

### 12. Electronic clap

#### Character

- several short noise bursts
- narrow time spacing
- bright but not piercing spectrum
- short synthetic tail

#### Synthesis recipe

Create two to four decaying noise bursts separated by small delays. Mix them below full level before quantization.

### 13. Closed hi-hat

#### Character

- very short
- high-frequency
- low in the mix
- mechanically precise

Remove low-frequency content and keep the tail short. Hats should not mask the lead or arpeggio.

### 14. Open hi-hat

#### Character

- brighter and longer than the closed hat
- controlled decay
- useful on offbeats

Design the tail around the next trigger on the same Paula channel.

### 15. Combined percussion

Recommended combined samples:

- `KICK+SNARE`
- `KICK+CLAP`
- `KICK+OPEN HAT`
- `SNARE+CLAP`
- `HAT+SHAKER`

For every combined sample:

1. align transients
2. balance components before quantization
3. preserve kick body when present
4. inspect phase interaction
5. remove DC offset
6. retain headroom
7. verify signed 8-bit output
8. keep byte length even
9. document the simultaneous event replaced

Do not claim channel capacity was released unless the pattern actually uses the combined sample instead of two simultaneous channel events.

### 16. Noise riser and sweep

#### Character

- filtered noise motion
- increasing brightness or amplitude
- transition into a new section

Create the motion directly in the sample or with supported tracker volume effects. Keep the sweep short enough to fit the arrangement.

### 17. Synthetic impact

Combine a short noise transient, a controlled tonal body and a rapidly decaying low component. Use sparingly at structural transitions.

### 18. Laser or science-fiction effect

Use a sine, square or filtered-noise source with a rapid pitch sweep. Keep the result original and avoid copying a recognizable effect from a film, game or record.

### 19. Reverse-style transition

Generate an original swell by reversing a self-created noise, cymbal-like or tonal envelope before final quantization. Confirm the result does not contain an imported protected recording.

## Simulated 1980s echo

ProTracker has no dedicated digital echo command.

Create echo by repeating notes at lower volume:

- on another channel for overlapping tails
- on the same channel when interruption is acceptable
- on the same row with `EDx` for tick-level delay
- across several taps with progressively lower `Cxx`

Example:

```text
ROW   SOURCE          ECHO
00    C-3 07 C38      --- -- ---
02    --- -- ---      C-3 07 C22
04    --- -- ---      C-3 00 C14
```

Volume is channel state. Selecting a new sample may restore its header volume, so use explicit `Cxx` when state is ambiguous.

For stereo bounce, alternate delayed copies between:

- channels 1 and 4: left
- channels 2 and 3: right

Every echo must document source row, destination row or tick, channel, volume attenuation and channel cost.

## Loop design

A genuine loop must have:

- repeat length greater than the minimum non-looping placeholder
- repeat range completely inside the sample
- even byte offsets and lengths
- compatible start and end waveform values
- controlled slope discontinuity
- preserved fundamental
- no accidental silence
- no click, buzz or unintended pitch

Prefer a loop inside the stable body after the attack.

For a short oscillator loop, use an integer number of complete waveform cycles and verify the resulting fundamental:

```text
fundamental = playback rate × cycles / loop length in samples
```

Do not use sustained arpeggio strings on a one-shot sample or placeholder loop.

## Conversion and quantization workflow

1. Generate or obtain a legally usable mono source.
2. Remove DC offset.
3. Identify the intended fundamental and strongest harmonics.
4. Choose the tracker reference period and effective source rate.
5. Resample with an appropriate low-pass filter.
6. Set headroom before quantization.
7. Convert to signed 8-bit PCM.
8. Recheck peak, RMS and DC offset after conversion.
9. Make the byte length even.
10. Define and validate loop fields.
11. Test every tracker note actually used.
12. Render the sample inside the four-channel arrangement.

Do not solve a weak sound only by increasing volume. Check pitch, octave, duration, envelope, loop, spectrum and competition from other channels.

## Suggested compact sample inventory

For a flexible 1980s-inspired module:

```text
01 KICK
02 KICK+SNARE
03 KICK+OPEN HAT
04 CLOSED HAT
05 PULSE BASS
06 LOOPED ARPEGGIO WAVE
07 ANALOGUE LEAD
08 GLASS PLUCK
09 SYNTH BRASS STAB
10 STRINGS OR PAD
11 CLAP
12 NOISE SWEEP
13 IMPACT
14 SCIENCE-FICTION EFFECT
```

Do not include every category automatically. Select only samples needed by the arrangement.

## Four-channel planning example

```text
Channel 1 left  — drums and combined percussion
Channel 2 right — bass
Channel 3 right — looped arpeggio, pad or stab
Channel 4 left  — lead, pluck or echo
```

During a breakdown, temporarily release the bass or drums so another channel can carry overlapping echo or pad material.

## Mandatory validation report

Report:

- sample name and musical role
- byte length
- signed 8-bit status
- header volume and finetune
- loop start, loop length and loop end
- measured or synthesis-derived fundamental
- used note range
- PAL and NTSC playback-rate range
- peak, RMS, DC offset and clipping
- whether the sample is one-shot or genuinely looped
- every `0xy` use
- every sustained arpeggio-string continuation
- every combined-sample trigger
- every simulated echo and its channel cost
- renderer support and limitations

Reject and regenerate samples that are silent, wrongly tuned, badly looped, clipped, excessively harsh, perceptually weak or musically inappropriate.

## Originality requirement

Use broad historical vocabulary only.

Do not copy:

- commercial sample-pack audio
- protected recordings
- recognizable presets captured from copyrighted demos
- identifiable melodies or riffs
- signature sound sequences
- complete arrangements

When a user provides a reference that cannot be heard or inspected directly, state the limitation. Do not claim exact auditory analysis. Use this document only as a general reconstruction guide until legally usable audio or precise user descriptions are available.

## Credits

Methodology and technical direction: Fabrizio Radica  
Project: RadicaDesign  
Website: www.radicadesign.com
